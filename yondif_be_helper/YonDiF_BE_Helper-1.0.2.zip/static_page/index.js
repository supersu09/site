let querySchemaInput, filterVOOutput, autoConvertSwitch, convertButton, autoFormatQuerySwitch, autoFormatFilterSwitch, errorMessage;
// 转换函数
function convertQuerySchemaToFilterVO(querySchema) {
  try {
    // 解析JSON字符串
    const ori = JSON.parse(querySchema);
    if (ori.queryScheme) {
      ori.condition = ori.queryScheme;
      delete ori['queryScheme'];
      if (ori.condition.conditions) {
        ori.condition.commonVOs = ori.condition.conditions
        delete ori.condition['conditions']
        ori.condition.commonVOs.forEach(condition => {
          condition.itemName = condition.name
          condition.compareLogic = condition.op
          condition.value1 = condition.v1
          condition.value2 = condition.v2
          delete condition['name']
          delete condition['op']
          delete condition['v1']
          delete condition['v2']
        });
      }
    }
    // 格式化JSON
    return JSON.stringify(ori, null, 2);
  } catch (error) {
    console.error('转换失败:', error);
    return "转换失败";
  }
}

// 验证JSON格式
function validateJSON(input) {
  try {
    JSON.parse(input);
    return true;
  } catch (error) {
    return false;
  }
}

// 格式化JSON字符串
function formatJSON(input) {
  try {
    return JSON.stringify(JSON.parse(input), null, 2);
  } catch (error) {
    return input;
  }
}

function compressJSON(input) {
  try {
    return JSON.stringify(JSON.parse(input));
  } catch (error) {
    return input;
  }
}

// 执行转换
function performConversion() {
  const querySchema = querySchemaInput.value;
  if (!querySchema.trim() || !validateJSON(querySchema)) {
    filterVOOutput.value = '';
    if (!querySchema.trim()) {
      querySchemaInput.classList.remove('error');
      errorMessage.style.display = 'none';
    } else {
      querySchemaInput.classList.add('error');
      errorMessage.style.display = 'block';
    }
    return;
  }
  const filterVO = convertQuerySchemaToFilterVO(querySchema);
  if (validateJSON(filterVO)) {
    if (autoFormatFilterSwitch.checked) {
      filterVOOutput.value = compressJSON(filterVO);
    } else {
      filterVOOutput.value = filterVO;
    }
  } else {
    filterVOOutput.value = '';
  }
  querySchemaInput.value = JSON.stringify(JSON.parse(querySchema), null, 2);
  querySchemaInput.classList.remove('error');
  errorMessage.style.display = 'none';
}

// DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
  // 获取DOM元素
  querySchemaInput = document.getElementById('querySchema');
  filterVOOutput = document.getElementById('filterVO');
  autoConvertSwitch = document.getElementById('autoConvert');
  convertButton = document.getElementById('convertButton');
  autoFormatQuerySwitch = document.getElementById('autoFormatQuery');
  autoFormatFilterSwitch = document.getElementById('autoFormatFilter');

  // 创建错误提示元素
  errorMessage = document.createElement('div');
  errorMessage.className = 'error-message';
  errorMessage.textContent = '输入数据不是JSON格式';
  querySchemaInput.parentElement.style.position = 'relative';
  querySchemaInput.parentElement.appendChild(errorMessage);

  // 监听转换按钮点击事件
  convertButton.addEventListener('click', performConversion);

  // 监听自动转换开关变化
  autoConvertSwitch.addEventListener('change', function () {
    convertButton.disabled = this.checked;
    if (this.checked) {
      performConversion();
    }
  });

  // 监听QuerySchema输入变化
  querySchemaInput.addEventListener('input', function () {
    if (autoFormatQuerySwitch.checked) {
      const value = querySchemaInput.value;
      if (validateJSON(value)) {
        querySchemaInput.value = formatJSON(value);
      }
    }
    if (autoConvertSwitch.checked) {
      performConversion();
    }
  });

  // 初始化按钮状态
  convertButton.disabled = autoConvertSwitch.checked;
});
